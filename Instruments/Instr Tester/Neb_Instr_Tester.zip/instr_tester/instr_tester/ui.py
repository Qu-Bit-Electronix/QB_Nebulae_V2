import time

class UserInterface(object):
    def __init__(self, controlhandler):
        self.controlhandler = controlhandler

    def update(self):
        pass
